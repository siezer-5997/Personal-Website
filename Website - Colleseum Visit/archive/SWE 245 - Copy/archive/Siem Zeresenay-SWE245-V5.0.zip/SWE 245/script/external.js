function myFunction() {
    var e = document.getElementById('a');
    var st1 = e.value;
    var s = document.getElementById('b');
    var n = s.value;
    var d = document.getElementById('c');
    var m = d.value;
    var Total;
  
    Total = (st1 * m) / n;
    document.getElementById('solution').innerHTML=Total
  }